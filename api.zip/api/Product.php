<?php

require 'conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $sql = 'INSERT INTO product (name, description, price, quantity_in_stock, category_id) VALUES (?, ?, ?,?,?)';

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$input['name'], $input['description'], $input['price'], $input['quantity_in_stock'], $input['cat    egory_id']]);
    echo json_encode('Product added');
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $sql = 'SELECT * FROM productcatalog';
    $stmt = $pdo->query($sql);
    $products = $stmt->fetchAll();
    echo json_encode($products);
}
