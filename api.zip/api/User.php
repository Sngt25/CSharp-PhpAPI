<?php

require 'conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $sql = 'INSERT INTO _user (username, email, address) VALUES (?, ?, ?)';

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$input['username'], $input['email'], $input['address']]);
    echo json_encode('User added');
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $sql = 'SELECT user_id, username, email, address FROM _user';
    $stmt = $pdo->query($sql);
    $products = $stmt->fetchAll();
    echo json_encode($products);
}
