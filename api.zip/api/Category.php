<?php

require 'conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    //sellect only category_id, category_name
    // $sql = 'SELECT * FROM category';
    $sql = 'SELECT category_id, category_name FROM category';
    $stmt = $pdo->query($sql);
    $products = $stmt->fetchAll();
    echo json_encode($products);
}
